// JavaScript source code


/* ***********************************************************************************
 * *************************** Movie object ******************************************
 * ********************************************************************************** */

let Movie = function (aTitle, aRating) {

    this.title = aTitle;
    this.rating = Number(aRating);

    console.log("in constructor title is: " + this.title);
    console.log("in constructor rating is: " + this.rating);

    //----------------------------------------------------------
    // isValid()
    //
    // insure title is not blank and rating is an integer 1 - 5
    //----------------------------------------------------------
    this.isValid = function () {

        if ((this.title == "") || isNaN(this.rating)) {
            return false;
        }
        else if (!Number.isInteger(this.rating) ) {
            return false;
        }
        else if (this.rating <= 0 || this.rating > 5) {
            return false;
        }
        else {
            console.log("valid movie");
            return true;
        }// end else true
        

    }; // end validate


    //------------------------------------------------
    // toString() 
    //------------------------------------------------
    this.toString = function () {
        let movieTitleString = this.title + "  &nbsp; &nbsp;";
        let movieRatingString = "";

         //set color based on if it is good or not
         //strong = gold, em = red
        if (this.rating > 2) {
            movieRatingString += "<strong>";
        }
        else {
            movieRatingString += "<em>";
        }

        let i = 1;
        for (i = 1; i <= this.rating; i++) {
            movieRatingString += "&#9733";  // add a star!
        }

        if (this.rating > 2) {
            movieRatingString += "</strong>";
        }
        else {
            movieRatingString += "</em>";
        }

        //movieRatingString += "</strong>";

        console.log("in toString");
        console.log(movieTitleString + movieRatingString);

        return (movieTitleString + movieRatingString);
    }; // end toString

};// end Movie constructor


