// JavaScript source code
/* ***********************************************************************************
 * *************************** declarations section **********************************
 * ********************************************************************************** */

// Note: these are all global data variables 

// NOTE: for arrays.  [ [], [] ] is an array whose first index only goes to 1 (0, 1) and the second index 
// can go as far as desired.  ie a 2 by infinite array.  a [[], [], []] creates a 3 by infinite and so on.
// a [ [ [], [] ] ] creates a 1 by 2 by infinte...  similarly [ [ [], [] ], [ [], [] ] ] creates a 2 by 2 by infinte.

// Movie list array
let movieArray = [];

/* ********************************************************************* */
/* ***************** HTML Page Items *********************************** */
/* ********************************************************************* */

// the inputs and list output
let titleInput = document.querySelector("#MovieTitle");
let ratingInput = document.querySelector("#MovieRating");  
let movieList = document.querySelector("#MovieList");  

// set up the button handlers
let addMovieBtn = document.getElementById("AddMovieButton");
addMovieBtn.style.cursor = "pointer";
addMovieBtn.addEventListener("click", addMovie, false);

let showMovieListBtn = document.getElementById("ShowListButton");
showMovieListBtn.style.cursor = "pointer";
showMovieListBtn.addEventListener("click", showList, false);

/* ********************************************************************* */
/* ***************** Button Handler Functions ************************** */
/* ********************************************************************* */


//----------------------------------------------------------------
// addMovie
//
// Discription: gets the input from the page and creates a movie 
//              object.  Verifies that the object is valid.  If so,
//              adds the movie to the movie list array and clears the
//              inputs.  If not valid, the function informs the user 
//              via a popup, that the input is not valid. 
//--------------------------------------------------------------------
function addMovie() {
    let nextMovie = new Movie(titleInput.value, ratingInput.value);

    console.log("in addMovie");

    if (nextMovie.isValid()) {
        // add to array
        movieArray.push(nextMovie);
        console.log("added movie");
    }
    else {
        // alert user to error
        window.alert("Data Entry Error:  Movie title must not be empty and the rating must be an integer between 1 and 5 inclusive. Movie data can not be added.");
    }

    // blow away anything in the input boxes
    titleInput.value = "";
    ratingInput.value = "";

} // end function addMovie


//----------------------------------------------------------------
// showList
//
// Discription: displays the items in the movie array by creating
//              li elements and adding them to the existing ul
//              node on the page After it has deleted all existing li
//              elements.
//--------------------------------------------------------------------
function showList() {
    console.log("in showList");

    /* when using a ul list: */
    //while (movieList.childNodes[0] != null) {
    //    movieList.removeChild(movieList.childNodes[0]);
    //    console.log("removed a child");
    //}

    //let i = 0;
    //let arrayEnd = movieArray.length;
    //console.log("array end is: " + arrayEnd);
    //for (i = 0; i < arrayEnd; i++) {
    //    let newItem = document.createElement("li");
    //    newItem.innerText = movieArray[i].toString();

    //    console.log("just created new item");
    //    console.log(newItem);

    //    movieList.appendChild(newItem);
    //}// end for loop

    /* when using a div */

    let i = 0;
    let arrayEnd = movieArray.length;
    let listString = "";
    console.log("array end is: " + arrayEnd);

    for (i = 0; i < arrayEnd; i++) {
     
        listString += movieArray[i].toString();
        listString += "<br />";

        console.log("just added new string");
        console.log(movieArray[i].toString());

     }// end for loop

    // overwrite anything in display list with new list
    movieList.innerHTML = listString;

    // now display it
    (document.getElementById("ListHeader")).style.display = "block";
     movieList.style.display = "block";

} // end function addMovie