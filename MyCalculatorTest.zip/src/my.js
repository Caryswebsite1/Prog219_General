buttonAdd = function () {
    var answer = 0
    answer = answer + (Number)($("#input1").val());
    answer = answer + (Number)($("#input2").val());
    $("#answer").val(answer);
}

buttonSubtract = function () {
    var answer = 0
    answer = answer + (Number)($("#input1").val());
    answer = answer - (Number)($("#input2").val());
    $("#answer").val(answer);
}

buttonMaxVal = function () {
    var answer = 0
    numbers = [];
    numbers.push((Number)($("#input1").val()));
    numbers.push((Number)($("#input2").val()));
    numbers.push((Number)($("#input3").val()));
    numbers.push((Number)($("#input4").val()));
    numbers.push((Number)($("#input5").val()));
    console.log(numbers);
    answer = max = Math.max.apply(null, numbers);
    $("#answer").val(answer);
}

buttonAverage = function () {
    var answer = 0
    answer = answer + (Number)($("#input1").val());
    answer = answer + (Number)($("#input2").val());
    answer = answer + (Number)($("#input3").val());
    answer = answer + (Number)($("#input4").val());
    answer = answer + (Number)($("#input5").val());
    answer = answer / 5;
    $("#answer").val(answer);
}