describe("Calc", function () {

    beforeAll(function () {
        $('#input1').val(10);
        $('#input2').val(10);
        $('#input3').val(10);
        $('#input4').val(10);
        $('#input5').val(10);
    })



    it("should be able to Add 2 entries", function () {
        buttonAdd();
        var actual = (Number)($("#answer").val());
        var expected = 20;
        expect(expected).toEqual(actual);

    });


    it("should be able to Subtract 2 entries", function () {
        buttonSubtract();
        var actual = (Number)($("#answer").val());
        var expected = 0;
        expect(expected).toEqual(actual);

    });


    it("should be able to Average all entries", function () {
        buttonAverage();
        var actual = (Number)($("#answer").val());
        var expected = 10;
        expect(expected).toEqual(actual);

    });


});